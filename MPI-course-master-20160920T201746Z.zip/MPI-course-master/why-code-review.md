# Why Version Control
* Manageable Changesets
* Complete history of your code-changes
* Easier Collaboration
* Easier deployment
* Rollback your code if needed

# Why code-review?
* As a learning tool

# Options
## hosted
* https://github.com
* https://www.atlassian.com/software/bitbucket
* https://about.gitlab.com

## on-premise
* https://github.com
* https://enterprise.github.com/features
* https://www.atlassian.com/software/bitbucket
* https://www.gerritcodereview.com
* https://about.gitlab.com
