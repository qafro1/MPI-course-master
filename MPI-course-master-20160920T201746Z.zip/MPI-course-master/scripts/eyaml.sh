#!/bin/sh
alias evim='/opt/puppetlabs/puppet/bin/eyaml edit --pkcs7-public-key /etc/puppetlabs/puppet/keys/public_key.pkcs7.pem --pkcs7-private-key /etc/puppetlabs/puppet/keys/private_key.pkcs7.pem '
