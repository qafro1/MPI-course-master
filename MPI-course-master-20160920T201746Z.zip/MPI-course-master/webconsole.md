# Fix for the PuppetDB 4.x issue:

Only apply this if it is still required.

    https://github.com/spotify/puppetexplorer/issues/49
