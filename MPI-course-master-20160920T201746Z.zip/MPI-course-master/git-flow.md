# Git flow
* http://nvie.com/posts/a-successful-git-branching-model/

## Branches used for modules
* development => develop
* release => master

## Branches used for Control repo
* development => integration
* release => testing

## Installation
* https://github.com/nvie/gitflow/wiki/Manual-installation
